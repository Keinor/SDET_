package tests;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.SearchPage;

public class WholeNumberOperations {
    private static WebDriver driver;

    @BeforeMethod
    public void beforeMethod() {
        driver = new ChromeDriver();
        driver.get("http://yandex.ru");
    }

    @Test
    public void searchTest() throws InterruptedException {
        SearchPage searchPage = PageFactory.initElements(driver, SearchPage.class);
        searchPage.typeText("калькулятор");
        searchPage.clickSubmitButton();
        searchPage.calcText("(1 + 2) × 3 - 40 / 5");
        Thread.sleep(3000); //задержка для отображения
    }

    @Test
    public void searchTestZero() throws InterruptedException {
        SearchPage searchPage = PageFactory.initElements(driver, SearchPage.class);
        searchPage.typeText("калькулятор");
        searchPage.clickSubmitButton();
        searchPage.calcText("6/0");
        Thread.sleep(3000);
    }

    @Test
    public void searchTestSin() throws InterruptedException {
        SearchPage searchPage = PageFactory.initElements(driver, SearchPage.class);
        searchPage.typeText("калькулятор");
        searchPage.clickSubmitButton();
        searchPage.calcText("sin");
        searchPage.clickEnter();
        Thread.sleep(3000);
    }

    @AfterMethod
    public void after() {
        driver.quit();
    }
}
