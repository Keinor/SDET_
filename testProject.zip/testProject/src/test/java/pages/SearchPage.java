package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SearchPage {

    public SearchPage(WebDriver driver){
        this.driver = driver;
    }

    private WebDriver driver;
    @FindBy(css = "input[id='text']")
    private WebElement inputField;

    @FindBy(css = "div[class='search2__button'] button")
    private WebElement submitButton;

    @FindBy(css = "input[class='input__control']")
    private WebElement calcField;

    @FindBy(xpath = "//div[@class='calculator__row'][5] //button[6]")
    private WebElement buttEnter;

    public void typeText(String text){
        inputField.sendKeys(text);
    }

    public void clickSubmitButton() {
        submitButton.click();
    }
    public void calcText(String text){
        calcField.sendKeys(text);
    }
    public void clickEnter(){
        buttEnter.click();
    }


}
